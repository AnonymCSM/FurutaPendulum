/* _inputParameters: an object with different values for the model parameters */
function remFuruta(_topFrame,_libraryPath,_codebasePath, _inputParameters) {
  var _model = EJSS_CORE.createAnimationLMS();
  var _view;
  var _isPlaying = false;
  var _isPaused = true;
  var _isMobile = (navigator===undefined) ? false : navigator.userAgent.match(/iPhone|iPad|iPod|Android|BlackBerry|Opera Mini|IEMobile/i);

var _stringProperties = {};
  var _tools = {
    showInputDialog : EJSS_INTERFACE.BoxPanel.showInputDialog,
    showOkDialog : EJSS_INTERFACE.BoxPanel.showOkDialog,
    showOkCancelDialog : EJSS_INTERFACE.BoxPanel.showOkCancelDialog,
    downloadText: EJSS_TOOLS.File.downloadText,
    uploadText: function(action) { EJSS_TOOLS.File.uploadText(_model,action); } 
  };

var sarlab = new SarlabProxy('false', '62.204.199.224', 'SARLABV8.0', '80', 'PenduloFuruta'); _model._sarlab = sarlab; _model._sarlab.connect = function(callback) { this.connectExperience(this.experience, function() { _model._userUnserialize({'cameraURL':_model._sarlab.getCamUrlById('Camara Pendulo Furuta', 'axis-cgi/mjpg/video.cgi')});labview.transport.setHost(_model._sarlab.getHTTPUrlById('RIP Pendulo Furuta', '')); if(callback != undefined) callback(); }.bind(_model)); }
var __conf = {'host':'http://62.204.199.224/SARLABV8.0/proxy?key=123&url=http://10.192.38.28:8080/','port':''};
	var __transport = new SSETransport(__conf);
	_model.labview = new RIPClient(__transport);
	_model._rip = _model.labview;
	var labview = _model.labview;
	_model.labview.setDefaultExperience('Pendulo');
	_model.labview.__connect__ = _model.labview.connect;
	_model.labview.connect = function(expid, callback) {
	if(callback != undefined) {
		this.__connect__(expid, function(response) {
	this.updateEjsVariables(response);
	callback(response);
	});
	} else {
		this.__connect__(expid, this.updateEjsVariables);
	}
	};
// Auto-generated method 
labview.updateEjsVariables = function(result) {
	t = result['t'];
u = result['u'];
alpha = result['alpha'];
beta = result['beta'];
dalpha = result['dalpha'];
dbeta = result['dbeta'];

	_model.getView()._update();
}
// Auto-generated method Init
labview.init = function(callback) {
	this.post('eval', ['']);
	this.sync(function(response) {
			this._isConnected = (response[0].result !== undefined);
		if(callback != undefined) {
			callback();
		};
	}.bind(this));
}
labview._isConnected = false
labview.isConnected = function() {
return this._isConnected;}
// Auto-generated method step()
labview.step = function(callback) {
	this.post('set', [[], []]);
	this.post('eval', ['']);
	this.post('step', [1]);
	this.post('get', [['t','u','alpha','beta','dalpha','dbeta']]);
	this.sync(function(response) {
			var result = response[3].result;
			t = result[0][0];
u = result[1][0];
alpha = result[2][0];
beta = result[3][0];
dalpha = result[4][0];
dbeta = result[5][0];

		if(callback != undefined) {
			callback(result);
		}
	});
}
  function _play()  { _isPaused = false; _isPlaying = true;  _model.play();  }
  function _pause() { _isPaused = true;  _isPlaying = false; _model.pause(); }
  function _step()  { _pause();  _model.step(); }
  function _reset() { _model.reset();  _isPaused = _model.isPaused(); _isPlaying = _model.isPlaying(); }
  _model._play  = _play;
  _model._pause = _pause;
  _model._step  = _step;
  _model._reset = _reset;
  function _update() { _model.update(); }
  function _initialize() { _model.initialize(); }
  function _setFPS(_fps) { _model.setFPS(_fps); }
  function _setDelay(_delay) { _model.setDelay(_delay); }
  function _setStepsPerDisplay(_spd) { _model.setStepsPerDisplay(_spd); }
  function _setUpdateView(_updateView) { _model.setUpdateView(_updateView); }
  function _setAutoplay(_auto) { _model.setAutoplay(_auto); }
  function _println(_message) { console.log(_message); }

  function _breakAfterThisPage() { _model.setShouldBreak(true); }

  function _resetSolvers() { if (_model.resetSolvers) _model.resetSolvers(); }

  function _saveText(name,type,content) { if (_model.saveText) _model.saveText(name,type,content); }

  function _saveState(name) { if (_model.saveState) _model.saveState(name); }

  function _saveImage(name,panelname) { if (_model.saveImage) _model.saveImage(name,panelname); }

  function _readState(url,type) { if (_model.readState) _model.readState(url,type); }

  function _readText(url,type,varname) { if (_model.readText) _model.readText(url,type,varname); }

  function _getStringProperty(propertyName) {
    var _value = _stringProperties[propertyName];
    if (_value===undefined) return propertyName;
    else return _value;
  }
  var __pagesEnabled = [];
  function _setPageEnabled(pageName,enabled) { __pagesEnabled[pageName] = enabled; }

  var alpha; // EjsS Model.Variables.EstadoPendulo.alpha
  var beta; // EjsS Model.Variables.EstadoPendulo.beta
  var dalpha; // EjsS Model.Variables.EstadoPendulo.dalpha
  var dbeta; // EjsS Model.Variables.EstadoPendulo.dbeta

  var connected; // EjsS Model.Variables.Tiempos.connected
  var t; // EjsS Model.Variables.Tiempos.t
  var Period; // EjsS Model.Variables.Tiempos.Period
  var period_sec; // EjsS Model.Variables.Tiempos.period_sec

  var studentCode; // EjsS Model.Variables.Control.studentCode
  var CameraOn; // EjsS Model.Variables.Control.CameraOn
  var cameraURL; // EjsS Model.Variables.Control.cameraURL
  var controller; // EjsS Model.Variables.Control.controller
  var DefaultController; // EjsS Model.Variables.Control.DefaultController
  var u; // EjsS Model.Variables.Control.u
  var betaRef; // EjsS Model.Variables.Control.betaRef

  var changeVariableValue; // EjsS Model.Variables.Intercambio.changeVariableValue

  var visibilityConnected; // EjsS Model.Variables.Vista.visibilityConnected
  var visibilityDisconnected; // EjsS Model.Variables.Vista.visibilityDisconnected

  _model.getOdes = function() { return []; };

  _model.removeEvents = function(){
  };

  function _serialize() { return _model.serialize(); }

  _model._userSerialize = function() {
    return {
      alpha : alpha,
      beta : beta,
      dalpha : dalpha,
      dbeta : dbeta,
      connected : connected,
      t : t,
      Period : Period,
      period_sec : period_sec,
      studentCode : studentCode,
      CameraOn : CameraOn,
      cameraURL : cameraURL,
      controller : controller,
      DefaultController : DefaultController,
      u : u,
      betaRef : betaRef,
      changeVariableValue : changeVariableValue,
      visibilityConnected : visibilityConnected,
      visibilityDisconnected : visibilityDisconnected
    };
  };

  _model._readParameters = function(json) {
    if(typeof json.alpha != "undefined") alpha = json.alpha;
    if(typeof json.beta != "undefined") beta = json.beta;
    if(typeof json.dalpha != "undefined") dalpha = json.dalpha;
    if(typeof json.dbeta != "undefined") dbeta = json.dbeta;
    if(typeof json.connected != "undefined") connected = json.connected;
    if(typeof json.t != "undefined") t = json.t;
    if(typeof json.Period != "undefined") Period = json.Period;
    if(typeof json.period_sec != "undefined") period_sec = json.period_sec;
    if(typeof json.studentCode != "undefined") studentCode = json.studentCode;
    if(typeof json.CameraOn != "undefined") CameraOn = json.CameraOn;
    if(typeof json.cameraURL != "undefined") cameraURL = json.cameraURL;
    if(typeof json.controller != "undefined") controller = json.controller;
    if(typeof json.DefaultController != "undefined") DefaultController = json.DefaultController;
    if(typeof json.u != "undefined") u = json.u;
    if(typeof json.betaRef != "undefined") betaRef = json.betaRef;
    if(typeof json.changeVariableValue != "undefined") changeVariableValue = json.changeVariableValue;
    if(typeof json.visibilityConnected != "undefined") visibilityConnected = json.visibilityConnected;
    if(typeof json.visibilityDisconnected != "undefined") visibilityDisconnected = json.visibilityDisconnected;
  };

  _model._inputAndPublicParameters = ["period_sec",  "controller",  "DefaultController",  "u",  "betaRef",  "changeVariableValue"]; 

  _model._outputAndPublicParameters = ["alpha",  "beta",  "dalpha",  "dbeta",  "t",  "controller",  "DefaultController",  "u",  "betaRef",  "changeVariableValue"];

  function _unserialize(json) { return _model.unserialize(json); }

  _model._userUnserialize = function(json) {
    _model._readParameters(json);
   _resetSolvers();
   _model.update();
  };

  _model.addToReset(function() {
    __pagesEnabled["Página Inicio"] = true;
  });

  _model.addToReset(function() {
    alpha = 0; // EjsS Model.Variables.EstadoPendulo.alpha
    beta = 0; // EjsS Model.Variables.EstadoPendulo.beta
    dalpha = 0; // EjsS Model.Variables.EstadoPendulo.dalpha
    dbeta = 0; // EjsS Model.Variables.EstadoPendulo.dbeta
  });

  _model.addToReset(function() {
    connected = false; // EjsS Model.Variables.Tiempos.connected
    t = 0; // EjsS Model.Variables.Tiempos.t
    Period = 10; // EjsS Model.Variables.Tiempos.Period
    period_sec = 0.01; // EjsS Model.Variables.Tiempos.period_sec
  });

  _model.addToReset(function() {
    studentCode = ""; // EjsS Model.Variables.Control.studentCode
    CameraOn = false; // EjsS Model.Variables.Control.CameraOn
    cameraURL = ""; // EjsS Model.Variables.Control.cameraURL
    DefaultController = true; // EjsS Model.Variables.Control.DefaultController
    u = 0; // EjsS Model.Variables.Control.u
    betaRef = 0; // EjsS Model.Variables.Control.betaRef
  });

  _model.addToReset(function() {
    changeVariableValue = 0; // EjsS Model.Variables.Intercambio.changeVariableValue
  });

  _model.addToReset(function() {
    visibilityConnected = "inline-block"; // EjsS Model.Variables.Vista.visibilityConnected
    visibilityDisconnected = "none"; // EjsS Model.Variables.Vista.visibilityDisconnected
  });

  if (_inputParameters) {
    _inputParameters = _model.parseInputParameters(_inputParameters);
    if (_inputParameters) _model.addToReset(function() { _model._readParameters(_inputParameters); });
  }

  _model.addToReset(function() {
    _model.setAutoplay(false);
    _model.setFPS(1);
    _model.setStepsPerDisplay(1);
  });

  //control deliberadamente ofuscado  // > CustomCode.Controlador:1
  function cd(a,b,c,d,e) {var w1A=Math.atan2(Math.sin(a),Math.cos(a));var orok=Math.atan2(Math.sin(e),Math.cos(e));var s256=0.5*100/50;var bQ2=c; var Q2b=bQ2-c+d;var Qb2=Math.atan2(Math.sin(b),Math.cos(b));if (Math.cos(w1A+Math.PI)*bQ2<0) {s256=s256-2;} var u=-4*orok-35*w1A+40/10*Qb2+3*Q2b/2-1.5*bQ2*2; if (Math.abs(w1A)>0.35) {u=0.1*0.095*6.3*s256*100*(0.5*3.226e-5*bQ2*bQ2+0.5*0.024*9.81*0.127*(0.1-Math.cos(w1A+Math.PI)+9/10)-30.0/1000)/(2*0.036);}return u;}  // > CustomCode.Controlador:2
  //prototipo vacío a modificar por blockly  // > CustomCode.Controlador:3
  controller = function(alpha,beta,dalpha,dbeta,betaRef) { }  // > CustomCode.Controlador:4
  //Dani me pasa el código con   // > CustomCode.Controlador:5
  //_model.sendToRemoteController(getRemoteCode());  // > CustomCode.Controlador:6
  //function sendToRemoteController(RemoteCode) {  // > CustomCode.Controlador:7
    _model.sendToRemoteController = function (RemoteCode){  // > CustomCode.Controlador:8
      studentCode=RemoteCode;  // > CustomCode.Controlador:9
      console.log("studentCode: "+studentCode);  // > CustomCode.Controlador:10
      labview.set(["StudentCode", "Custom/Default"], [studentCode, DefaultController]);  // > CustomCode.Controlador:11
    }  // > CustomCode.Controlador:12

  _model.addToInitialization(function() {
    if (!__pagesEnabled["Página Inicio"]) return;
    Period=1000*period_sec;//pasa de segundos a ms  // > Initialization.Página Inicio:1
    visibilityConnected = "none";  // > Initialization.Página Inicio:2
    visibilityDisconnected = "inline-block";  // > Initialization.Página Inicio:3
    connected = true;  // > Initialization.Página Inicio:4
  });

  _model.addToFixedRelations(function() { _isPaused = _model.isPaused(); _isPlaying = _model.isPlaying(); });

  _model.addToFixedRelations(function() { _isPaused = _model.isPaused(); _isPlaying = _model.isPlaying(); });

    _model._fontResized = function(iBase,iSize,iDelta) {
      _view._fontResized(iBase,iSize,iDelta);
  }; // end of _fontResized

  function _getViews() {
    var _viewsInfo = [];
    var _counter = 0;
    _viewsInfo[_counter++] = { name : "FurutaView", width : 1024, height : 768 };
    return _viewsInfo;
  } // end of _getViews

  function _selectView(_viewNumber) {
    _view = null;
    _view = new remFuruta_View(_topFrame,_viewNumber,_libraryPath,_codebasePath);
    var _view_super_reset = _view._reset;
    _view._reset = function() {
      _view_super_reset();
      switch(_viewNumber) {
        case -10 : break; // make Lint happy
        default :
        case 0:
          _view.webcam.linkProperty("On",  function() { return connected; }, function(_v) { connected = _v; } ); // FurutaView linking property 'On' for element 'webcam'
          _view.webcam.linkProperty("ImageUrl",  function() { return cameraURL; }, function(_v) { cameraURL = _v; } ); // FurutaView linking property 'ImageUrl' for element 'webcam'
          _view.PreriodTextField.linkProperty("Value",  function() { return period_sec; }, function(_v) { period_sec = _v; } ); // FurutaView linking property 'Value' for element 'PreriodTextField'
          _view.PreriodTextField.setAction("OnChange", function(_data,_info) {
  Period=1000*period_sec;//pasa de segundos a ms
  labview.set(["Period"], [Period]);

}); // FurutaView setting action 'OnChange' for element 'PreriodTextField'
          _view.valorReference.linkProperty("Value",  function() { return betaRef; }, function(_v) { betaRef = _v; } ); // FurutaView linking property 'Value' for element 'valorReference'
          _view.valorReference.setAction("OnChange", function(_data,_info) {
  labview.set(["betaRef"], [betaRef]);

}); // FurutaView setting action 'OnChange' for element 'valorReference'
          _view.sliderReference.setAction("OnRelease", function(_data,_info) {
  labview.set(["betaRef"], [betaRef]);

}); // FurutaView setting action 'OnRelease' for element 'sliderReference'
          _view.sliderReference.linkProperty("Minimum",  function() { return -Math.PI; } ); // FurutaView linking property 'Minimum' for element 'sliderReference'
          _view.sliderReference.linkProperty("Maximum",  function() { return Math.PI; } ); // FurutaView linking property 'Maximum' for element 'sliderReference'
          _view.sliderReference.linkProperty("Value",  function() { return betaRef; }, function(_v) { betaRef = _v; } ); // FurutaView linking property 'Value' for element 'sliderReference'
          break;
      } // end of switch
    }; // end of new reset

    _model.setView(_view);
    _model.reset();
    _view._enableEPub();
  } // end of _selectView

  _model.setAutoplay(false);
  _model.setFPS(1);
  _model.setStepsPerDisplay(1);
  _selectView(_model._autoSelectView(_getViews())); // this includes _model.reset()
  return _model;
}
function remFuruta_View (_topFrame,_viewNumber,_libraryPath,_codebasePath) {
  var _view;
  switch(_viewNumber) {
    case -10 : break; // make Lint happy
    default :
    case 0: _view = remFuruta_View_0 (_topFrame); break;
  } // end of switch

  if (_codebasePath) _view._setResourcePath(_codebasePath);

  if (_libraryPath) _view._setLibraryPath(_libraryPath);


  return _view;
} // end of main function

function remFuruta_View_0 (_topFrame) {
  var _view = EJSS_CORE.createView(_topFrame);

  _view._reset = function() {
    _view._clearAll();
    _view._addElement(EJSS_INTERFACE.panel,"Pendulum", _view._topFrame) // EJsS HtmlView.FurutaView: declaration of element 'Pendulum'
      ;

    _view._addElement(EJSS_INTERFACE.panel,"Camera", _view.Pendulum) // EJsS HtmlView.FurutaView: declaration of element 'Camera'
      .setProperty("Height","50%") // EJsS HtmlView.FurutaView: setting property 'Height' for element 'Camera'
      .setProperty("Width","50%") // EJsS HtmlView.FurutaView: setting property 'Width' for element 'Camera'
      ;

    _view._addElement(EJSS_DRAWING2D.drawingPanel,"panelDibujo", _view.Camera) // EJsS HtmlView.FurutaView: declaration of element 'panelDibujo'
      .setProperty("Background","rgba(255,255,255,0.0)") // EJsS HtmlView.FurutaView: setting property 'Background' for element 'panelDibujo'
      .setProperty("AutoScaleY",true) // EJsS HtmlView.FurutaView: setting property 'AutoScaleY' for element 'panelDibujo'
      .setProperty("AutoScaleX",true) // EJsS HtmlView.FurutaView: setting property 'AutoScaleX' for element 'panelDibujo'
      .setProperty("Foreground","rgba(255,255,255,0.0)") // EJsS HtmlView.FurutaView: setting property 'Foreground' for element 'panelDibujo'
      ;

    _view._addElement(EJSS_DRAWING2D.webCamImage,"webcam", _view.panelDibujo) // EJsS HtmlView.FurutaView: declaration of element 'webcam'
      ;

    _view._addElement(EJSS_INTERFACE.panel,"SlidersAndControllers", _view.Pendulum) // EJsS HtmlView.FurutaView: declaration of element 'SlidersAndControllers'
      ;

    _view._addElement(EJSS_INTERFACE.panel,"Reference", _view.SlidersAndControllers) // EJsS HtmlView.FurutaView: declaration of element 'Reference'
      ;

    _view._addElement(EJSS_INTERFACE.panel,"PeriodField", _view.Reference) // EJsS HtmlView.FurutaView: declaration of element 'PeriodField'
      .setProperty("Display","inline-block") // EJsS HtmlView.FurutaView: setting property 'Display' for element 'PeriodField'
      ;

    _view._addElement(EJSS_INTERFACE.imageAndTextButton,"PeriodLabel", _view.PeriodField) // EJsS HtmlView.FurutaView: declaration of element 'PeriodLabel'
      .setProperty("Text","Period(s)=") // EJsS HtmlView.FurutaView: setting property 'Text' for element 'PeriodLabel'
      ;

    _view._addElement(EJSS_INTERFACE.numberField,"PreriodTextField", _view.PeriodField) // EJsS HtmlView.FurutaView: declaration of element 'PreriodTextField'
      ;

    _view._addElement(EJSS_INTERFACE.panel,"textReference", _view.Reference) // EJsS HtmlView.FurutaView: declaration of element 'textReference'
      .setProperty("Display","inline-block") // EJsS HtmlView.FurutaView: setting property 'Display' for element 'textReference'
      ;

    _view._addElement(EJSS_INTERFACE.imageAndTextButton,"nameReference", _view.textReference) // EJsS HtmlView.FurutaView: declaration of element 'nameReference'
      .setProperty("Text","Reference=") // EJsS HtmlView.FurutaView: setting property 'Text' for element 'nameReference'
      ;

    _view._addElement(EJSS_INTERFACE.numberField,"valorReference", _view.textReference) // EJsS HtmlView.FurutaView: declaration of element 'valorReference'
      .setProperty("Format","0.00") // EJsS HtmlView.FurutaView: setting property 'Format' for element 'valorReference'
      .setProperty("Editable",true) // EJsS HtmlView.FurutaView: setting property 'Editable' for element 'valorReference'
      ;

    _view._addElement(EJSS_INTERFACE.slider,"sliderReference", _view.textReference) // EJsS HtmlView.FurutaView: declaration of element 'sliderReference'
      .setProperty("Step",0.01) // EJsS HtmlView.FurutaView: setting property 'Step' for element 'sliderReference'
      ;

  };

  return _view;
}



      var _model;
      var _scorm;
      window.addEventListener('load',
        function () { 
          _model =  new remFuruta("_topFrame","_ejs_library/",null);
          if (typeof _isApp !== "undefined" && _isApp) _model.setRunAlways(true);
          TextResizeDetector.TARGET_ELEMENT_ID = '_topFrame';
          TextResizeDetector.USER_INIT_FUNC = function () {
            var iBase = TextResizeDetector.addEventListener(function(e,args) {
              _model._fontResized(args[0].iBase,args[0].iSize,args[0].iDelta);
              },null);
            _model._fontResized(iBase);
          };
          _model.onload();
        }, false);
